"""Read transaction events from the fraud-transactions Kafka topic."""
import json
import os

from kafka import KafkaConsumer
from kafka.errors import KafkaError

BOOTSTRAP_SERVERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
TOPIC = os.getenv("KAFKA_TOPIC", "fraud-transactions")
GROUP_ID = os.getenv("KAFKA_GROUP_ID", "fraud-detection-day2-test")


def main():
    consumer = KafkaConsumer(
        TOPIC,
        bootstrap_servers=BOOTSTRAP_SERVERS.split(","),
        group_id=GROUP_ID,
        auto_offset_reset="earliest",
        enable_auto_commit=True,
        value_deserializer=lambda raw: json.loads(raw.decode("utf-8")),
        consumer_timeout_ms=0,
    )
    print(f"Listening to topic '{TOPIC}' at {BOOTSTRAP_SERVERS}. Press Ctrl+C to stop.")
    try:
        for message in consumer:
            print(
                f"Received topic={message.topic} partition={message.partition} "
                f"offset={message.offset}: {json.dumps(message.value, indent=2)}"
            )
    except KeyboardInterrupt:
        print("\nConsumer stopped.")
    except KafkaError as exc:
        raise SystemExit(f"Kafka consumer error: {exc}") from exc
    finally:
        consumer.close()


if __name__ == "__main__":
    main()
