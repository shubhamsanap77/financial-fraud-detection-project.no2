#!/usr/bin/env sh
set -eu
docker compose -f docker/docker-compose.yml exec kafka \
  /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --list
