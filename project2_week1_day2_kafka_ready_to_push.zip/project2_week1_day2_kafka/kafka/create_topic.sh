#!/usr/bin/env sh
set -eu

BOOTSTRAP_SERVER="${KAFKA_BOOTSTRAP_SERVER:-localhost:9092}"
TOPIC="${KAFKA_TOPIC:-fraud-transactions}"

echo "Creating topic '$TOPIC' on $BOOTSTRAP_SERVER ..."
docker compose -f docker/docker-compose.yml exec kafka \
  /opt/kafka/bin/kafka-topics.sh \
  --bootstrap-server "$BOOTSTRAP_SERVER" \
  --create --if-not-exists \
  --topic "$TOPIC" \
  --partitions 3 \
  --replication-factor 1

echo "Topic details:"
docker compose -f docker/docker-compose.yml exec kafka \
  /opt/kafka/bin/kafka-topics.sh \
  --bootstrap-server "$BOOTSTRAP_SERVER" \
  --describe --topic "$TOPIC"
