# Kafka Setup

This folder contains scripts to create and list the project's Kafka topic.

- Default broker: `localhost:9092`
- Default topic: `fraud-transactions`
- Partitions: `3`
- Replication factor: `1` (single-broker local development setup)

## Create the topic

From the repository root:

```bash
docker compose -f docker/docker-compose.yml up -d
# Wait until Kafka is healthy, then:
sh kafka/create_topic.sh
```

List topics:

```bash
sh kafka/list_topics.sh
```

Override the topic name with `KAFKA_TOPIC=your-topic` if needed. The scripts use Docker Compose's service name and the local broker endpoint for a local-development setup.
