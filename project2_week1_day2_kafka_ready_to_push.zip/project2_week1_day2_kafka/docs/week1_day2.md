# Project 2 — Week 1, Day 2: Apache Kafka Setup

## Project
Real-Time Financial Fraud Detection Pipeline

## Goal
Prepare a local Kafka broker using Docker Compose, create the transaction topic, and provide producer/consumer scripts to verify message flow.

## Deliverables
- `docker/docker-compose.yml`: single-node Kafka in KRaft mode; no ZooKeeper required.
- `kafka/create_topic.sh`: idempotently creates `fraud-transactions` with three partitions.
- `kafka/list_topics.sh`: lists available topics.
- `producer/kafka_producer.py`: publishes synthetic transaction events.
- `consumer/kafka_consumer.py`: reads and prints events.
- `requirements.txt`: Python Kafka client dependency.

## Run and verify

Run commands from the repository root.

1. Check Docker and Compose:
   ```bash
   docker --version
   docker compose version
   ```
2. Start Kafka:
   ```bash
   docker compose -f docker/docker-compose.yml up -d
   docker compose -f docker/docker-compose.yml ps
   ```
3. Create the topic:
   ```bash
   sh kafka/create_topic.sh
   ```
4. Install the Python dependency:
   ```bash
   python -m pip install -r requirements.txt
   ```
5. Terminal A — start consumer:
   ```bash
   python consumer/kafka_consumer.py
   ```
6. Terminal B — start producer:
   ```bash
   python producer/kafka_producer.py
   ```
7. Confirm the consumer prints synthetic transaction events. Stop either script with Ctrl+C.
8. Inspect Kafka logs if necessary:
   ```bash
   docker compose -f docker/docker-compose.yml logs --tail=100 kafka
   ```

## Configuration
- Broker exposed to the host at `localhost:9092`.
- Topic can be changed with `KAFKA_TOPIC`; producer and consumer default to `fraud-transactions`.
- Broker is configured for local development only: one broker, replication factor 1, no authentication/TLS. Do not use this configuration for production or real financial data.

## Status checklist
- [ ] Docker and Docker Compose versions confirmed on the target machine.
- [ ] Kafka container starts and becomes healthy.
- [ ] Topic creation/listing succeeds.
- [ ] Python dependency installs.
- [ ] Producer sends events and consumer receives them.
- [ ] Add screenshots/logs of successful local verification before marking the task fully tested.
