"""Send sample transaction events to the fraud-transactions Kafka topic."""
import json
import os
import time
import uuid
from datetime import datetime, timezone

from kafka import KafkaProducer
from kafka.errors import KafkaError

BOOTSTRAP_SERVERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
TOPIC = os.getenv("KAFKA_TOPIC", "fraud-transactions")


def make_transaction():
    """Create a clearly synthetic transaction event for pipeline testing."""
    return {
        "transaction_id": str(uuid.uuid4()),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "user_id": f"user_{int(time.time()) % 1000:04d}",
        "amount": round(10 + (time.time() % 500), 2),
        "currency": "USD",
        "payment_type": "TRANSFER",
        "is_synthetic_test_event": True,
    }


def main():
    producer = KafkaProducer(
        bootstrap_servers=BOOTSTRAP_SERVERS.split(","),
        value_serializer=lambda value: json.dumps(value).encode("utf-8"),
        key_serializer=lambda key: key.encode("utf-8"),
        acks="all",
        retries=5,
    )
    print(f"Producing synthetic events to topic '{TOPIC}' at {BOOTSTRAP_SERVERS}.")
    print("Press Ctrl+C to stop.")
    try:
        while True:
            event = make_transaction()
            future = producer.send(TOPIC, key=event["transaction_id"], value=event)
            metadata = future.get(timeout=10)
            print(
                f"Sent transaction_id={event['transaction_id']} "
                f"topic={metadata.topic} partition={metadata.partition} "
                f"offset={metadata.offset}"
            )
            time.sleep(2)
    except KeyboardInterrupt:
        print("\nProducer stopped.")
    except KafkaError as exc:
        raise SystemExit(f"Kafka producer error: {exc}") from exc
    finally:
        producer.flush()
        producer.close()


if __name__ == "__main__":
    main()
