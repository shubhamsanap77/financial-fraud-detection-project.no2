# Real-Time Financial Fraud Detection Pipeline — Project 2

This repository is being developed week by week. The Week 1, Day 2 contribution sets up Apache Kafka for transaction-event streaming.

## Week 1, Day 2: Kafka

### Requirements
- Docker Engine or Docker Desktop with Docker Compose v2
- Python 3.9+
- Internet access for pulling the Kafka image/installing the Python dependency

### Start Kafka

From the repository root:

```bash
docker compose -f docker/docker-compose.yml up -d
docker compose -f docker/docker-compose.yml ps
sh kafka/create_topic.sh
```

The local Kafka broker is exposed at `localhost:9092`. The topic is `fraud-transactions`.

### Test producer → Kafka → consumer

Install dependencies:

```bash
python -m pip install -r requirements.txt
```

Open two terminals from the repository root.

Terminal 1:

```bash
python consumer/kafka_consumer.py
```

Terminal 2:

```bash
python producer/kafka_producer.py
```

The producer emits synthetic transaction messages every two seconds. The consumer should print the received JSON messages. Use Ctrl+C to stop each process.

### Useful commands

```bash
sh kafka/list_topics.sh
docker compose -f docker/docker-compose.yml logs --tail=100 kafka
docker compose -f docker/docker-compose.yml down
```

To stop and remove the local Kafka data volume as well:

```bash
docker compose -f docker/docker-compose.yml down -v
```

**Warning:** `down -v` deletes the local Kafka data stored in the Docker volume. The configuration is for local development only and is not production-secure.

## Project roadmap
Planned components include transaction data ingestion, a streaming pipeline, a database, fraud detection/modeling, monitoring, and documentation. Keep each week's implementation and test evidence in its own documented contribution.
