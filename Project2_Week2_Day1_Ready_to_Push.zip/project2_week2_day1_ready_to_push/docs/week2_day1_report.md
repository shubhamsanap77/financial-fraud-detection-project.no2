# Project 2 — Week 2 Day 1 Report
## PaySim Transaction Data Analysis, Feature Engineering & Selection

### Objective
Prepare transaction data for downstream fraud-detection modeling by removing duplicate rows, profiling the dataset, and generating transaction- and balance-related features.

### Work completed in this package
- Automated CSV discovery from `data/paysim/` or a user-supplied input path.
- Duplicate-row removal.
- Time features from `step`: hour of day and day index.
- Transaction amount features: raw amount, `log1p(amount)`, zero-amount indicator, and high-amount indicator.
- One-hot encoded transaction type.
- Origin and destination balance changes.
- Balance consistency errors and absolute errors.
- Zero-balance indicators and amount-to-balance ratios.
- Feature report with data type, missing percentage, unique values, variance, and optional absolute correlation with the target.
- JSON summary of row counts, detected columns, target prevalence, and excluded target/flag columns.
- Unit tests for core feature generation, leakage exclusion from the feature report, and duplicate removal.

### Output files
Running the script creates:
- `data/processed/week2_day1/paysim_engineered_features.csv`
- `data/processed/week2_day1/feature_selection_report.csv`
- `data/processed/week2_day1/data_profile_summary.json`

### Run instructions
From the repository root:

```bash
pip install -r requirements.txt
python scripts/week2_day1_feature_engineering.py
```

If the dataset has a different name or location:

```bash
python scripts/week2_day1_feature_engineering.py --input path/to/paysim.csv
```

Run tests:

```bash
python -m unittest discover -s tests -v
```

### Feature selection notes
- `isFraud` is the label/target and must not be used as a model input.
- `isFlaggedFraud` is excluded from the feature ranking because it can reveal an existing detection outcome and create leakage.
- Account identifiers (`nameOrig`, `nameDest`) are not included as model features; they are high-cardinality identifiers.
- Correlation is an exploratory ranking only. The final model feature set should be selected using training data only and evaluated on a held-out split.
- Fraud datasets are typically imbalanced. Week 2 Day 1 does not claim model performance; model training and evaluation should be performed in the assigned later tasks.

### Data and privacy
Do not commit large raw datasets, customer identifiers, or secrets unless the repository owner explicitly requires them. Commit the script, tests, documentation, and small derived metadata; keep generated data out of Git when it is large.
