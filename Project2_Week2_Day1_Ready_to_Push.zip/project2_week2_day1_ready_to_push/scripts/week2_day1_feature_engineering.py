"""
Project 2 — Week 2 Day 1
PaySim transaction data profiling, feature engineering, and feature-selection report.

Usage from repository root:
    python scripts/week2_day1_feature_engineering.py
    python scripts/week2_day1_feature_engineering.py --input data/paysim/your_file.csv
    python scripts/week2_day1_feature_engineering.py --input path/to/file.csv --output-dir data/processed/week2_day1

The script never uses isFraud/isFlaggedFraud as model input features.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

TARGET_CANDIDATES = ("isFraud", "is_fraud", "fraud", "Churn", "target")
DROP_ID_COLUMNS = {"nameOrig", "nameDest", "nameorig", "namedest"}


def find_input_csv(explicit_path: str | None = None) -> Path:
    """Find a PaySim CSV; prefer the conventional data/paysim location."""
    if explicit_path:
        path = Path(explicit_path).expanduser()
        if not path.is_file():
            raise FileNotFoundError(f"Input CSV was not found: {path}")
        return path

    candidates = [
        Path("data/paysim/PS_20174392719_1491204439457_log.csv"),
        Path("data/paysim/paysim.csv"),
        Path("data/PS_20174392719_1491204439457_log.csv"),
    ]
    for path in candidates:
        if path.is_file():
            return path

    search_roots = [Path("data/paysim"), Path("data")]
    matches: list[Path] = []
    for root in search_roots:
        if root.exists():
            matches.extend(p for p in root.rglob("*.csv") if p.is_file())
    # Ignore generated outputs if the script is rerun.
    matches = [p for p in matches if "week2_day1" not in str(p).lower()]
    if matches:
        return sorted(matches, key=lambda p: (len(str(p)), str(p)))[0]

    raise FileNotFoundError(
        "No input CSV found. Put the PaySim CSV in data/paysim/ or pass "
        "--input path/to/your_dataset.csv."
    )


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Trim whitespace from column names while preserving original case."""
    result = df.copy()
    result.columns = [str(c).strip() for c in result.columns]
    return result


def _find_col(df: pd.DataFrame, names: Iterable[str]) -> str | None:
    lookup = {str(c).strip().lower(): c for c in df.columns}
    for name in names:
        if name.lower() in lookup:
            return lookup[name.lower()]
    return None


def engineer_features(raw_df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """
    Create leakage-aware features from PaySim-like transaction records.
    Returns engineered dataframe and a JSON-serializable profiling summary.
    """
    df = normalize_columns(raw_df)
    original_rows, original_cols = df.shape
    df = df.drop_duplicates().copy()
    duplicate_rows_removed = original_rows - len(df)

    # Coerce known numeric fields without failing on imperfect source files.
    numeric_candidates = [
        "step", "amount", "oldbalanceOrg", "newbalanceOrig",
        "oldbalanceDest", "newbalanceDest", "isFraud", "isFlaggedFraud",
    ]
    for name in numeric_candidates:
        col = _find_col(df, [name])
        if col is not None:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    step_col = _find_col(df, ["step"])
    amount_col = _find_col(df, ["amount"])
    type_col = _find_col(df, ["type"])
    old_org_col = _find_col(df, ["oldbalanceOrg", "old_balance_orig", "oldbalanceOrig"])
    new_org_col = _find_col(df, ["newbalanceOrig", "new_balance_orig", "newbalanceOrig"])
    old_dest_col = _find_col(df, ["oldbalanceDest", "old_balance_dest"])
    new_dest_col = _find_col(df, ["newbalanceDest", "new_balance_dest"])
    target_col = _find_col(df, TARGET_CANDIDATES)
    flagged_col = _find_col(df, ["isFlaggedFraud", "is_flagged_fraud"])

    features = pd.DataFrame(index=df.index)

    # Time features: PaySim step represents an hourly time step.
    if step_col:
        step = pd.to_numeric(df[step_col], errors="coerce")
        features["step"] = step
        features["hour_of_day"] = step.mod(24)
        features["day_index"] = np.floor(step / 24)
    else:
        features["step"] = np.nan
        features["hour_of_day"] = np.nan
        features["day_index"] = np.nan

    if amount_col:
        amount = pd.to_numeric(df[amount_col], errors="coerce").fillna(0).clip(lower=0)
        features["amount"] = amount
        features["amount_log1p"] = np.log1p(amount)
        features["amount_is_zero"] = (amount == 0).astype("int8")
    else:
        amount = pd.Series(0.0, index=df.index)
        features["amount"] = np.nan
        features["amount_log1p"] = np.nan
        features["amount_is_zero"] = 0

    # Transaction type as one-hot features; unknown types remain representable
    # through the type column in the raw dataset and do not crash the pipeline.
    if type_col:
        type_series = df[type_col].fillna("UNKNOWN").astype(str).str.strip()
        type_dummies = pd.get_dummies(type_series, prefix="type", dtype="int8")
        features = pd.concat([features, type_dummies], axis=1)

    # Balance movement and consistency features.
    if old_org_col and new_org_col:
        old_org = pd.to_numeric(df[old_org_col], errors="coerce").fillna(0)
        new_org = pd.to_numeric(df[new_org_col], errors="coerce").fillna(0)
        features["origin_balance_change"] = old_org - new_org
        features["origin_balance_error"] = old_org - amount - new_org
        features["origin_balance_error_abs"] = features["origin_balance_error"].abs()
        features["origin_balance_zero_after"] = (new_org == 0).astype("int8")
        features["origin_balance_zero_before"] = (old_org == 0).astype("int8")
        features["origin_amount_to_balance_ratio"] = amount / (old_org.abs() + 1.0)
    else:
        for col in (
            "origin_balance_change", "origin_balance_error",
            "origin_balance_error_abs", "origin_balance_zero_after",
            "origin_balance_zero_before", "origin_amount_to_balance_ratio",
        ):
            features[col] = np.nan

    if old_dest_col and new_dest_col:
        old_dest = pd.to_numeric(df[old_dest_col], errors="coerce").fillna(0)
        new_dest = pd.to_numeric(df[new_dest_col], errors="coerce").fillna(0)
        features["destination_balance_change"] = new_dest - old_dest
        features["destination_balance_error"] = old_dest + amount - new_dest
        features["destination_balance_error_abs"] = features["destination_balance_error"].abs()
        features["destination_balance_zero_before"] = (old_dest == 0).astype("int8")
        features["destination_balance_zero_after"] = (new_dest == 0).astype("int8")
        features["destination_amount_to_balance_ratio"] = amount / (old_dest.abs() + 1.0)
    else:
        for col in (
            "destination_balance_change", "destination_balance_error",
            "destination_balance_error_abs", "destination_balance_zero_before",
            "destination_balance_zero_after", "destination_amount_to_balance_ratio",
        ):
            features[col] = np.nan

    # Helpful cross-feature indicators.
    if "origin_balance_change" in features and "destination_balance_change" in features:
        features["balance_change_gap"] = (
            features["origin_balance_change"] - features["destination_balance_change"]
        ).abs()
    features["amount_over_100k"] = (features["amount"].fillna(0) > 100_000).astype("int8")

    # Attach target only for downstream training/evaluation; never in feature list.
    if target_col:
        features[target_col] = df[target_col].values
    if flagged_col:
        features[flagged_col] = df[flagged_col].values

    # IDs are deliberately not added as features: they are high-cardinality identifiers.
    feature_columns = [
        c for c in features.columns
        if c not in {target_col, flagged_col} and c.lower() not in DROP_ID_COLUMNS
    ]

    # Rank features by missingness and variance; if a target exists, add a simple
    # numeric correlation ranking as an exploratory signal, not a causal claim.
    report_rows = []
    target_numeric = None
    if target_col and pd.api.types.is_numeric_dtype(features[target_col]):
        target_numeric = pd.to_numeric(features[target_col], errors="coerce")

    for col in feature_columns:
        s = features[col]
        numeric_s = pd.to_numeric(s, errors="coerce")
        valid = numeric_s.dropna()
        row = {
            "feature": col,
            "dtype": str(s.dtype),
            "missing_pct": round(float(s.isna().mean() * 100), 4),
            "unique_values": int(s.nunique(dropna=True)),
            "variance": float(valid.var()) if len(valid) > 1 else 0.0,
            "abs_target_correlation": np.nan,
        }
        if target_numeric is not None and numeric_s.notna().sum() > 1:
            pair = pd.concat([numeric_s, target_numeric], axis=1).dropna()
            if len(pair) > 1 and pair.iloc[:, 0].nunique() > 1 and pair.iloc[:, 1].nunique() > 1:
                row["abs_target_correlation"] = abs(float(pair.iloc[:, 0].corr(pair.iloc[:, 1])))
        report_rows.append(row)

    report = pd.DataFrame(report_rows)
    if not report.empty:
        report = report.sort_values(
            ["abs_target_correlation", "variance"],
            ascending=[False, False],
            na_position="last",
        )

    fraud_rate = None
    if target_col:
        vals = pd.to_numeric(df[target_col], errors="coerce")
        fraud_rate = float(vals.mean()) if vals.notna().any() else None

    summary = {
        "source_rows": int(original_rows),
        "rows_after_duplicate_removal": int(len(df)),
        "duplicate_rows_removed": int(duplicate_rows_removed),
        "source_columns": int(original_cols),
        "engineered_feature_count": int(len(feature_columns)),
        "target_column": target_col,
        "target_positive_rate": fraud_rate,
        "source_columns_detected": {
            "step": step_col, "type": type_col, "amount": amount_col,
            "oldbalanceOrg": old_org_col, "newbalanceOrig": new_org_col,
            "oldbalanceDest": old_dest_col, "newbalanceDest": new_dest_col,
        },
        "excluded_from_model_features": [x for x in [target_col, flagged_col] if x],
        "note": "Correlation ranking is exploratory only; it does not establish causation.",
    }
    return features.reset_index(drop=True), {"summary": summary, "feature_report": report}


def main() -> None:
    parser = argparse.ArgumentParser(description="Week 2 Day 1 PaySim feature engineering")
    parser.add_argument("--input", help="Path to the source PaySim CSV")
    parser.add_argument(
        "--output-dir", default="data/processed/week2_day1",
        help="Directory for engineered output files",
    )
    args = parser.parse_args()

    source = find_input_csv(args.input)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    raw = pd.read_csv(source, low_memory=False)
    engineered, results = engineer_features(raw)

    engineered_path = output_dir / "paysim_engineered_features.csv"
    report_path = output_dir / "feature_selection_report.csv"
    summary_path = output_dir / "data_profile_summary.json"

    engineered.to_csv(engineered_path, index=False)
    results["feature_report"].to_csv(report_path, index=False)
    summary_path.write_text(json.dumps(results["summary"], indent=2), encoding="utf-8")

    print("Week 2 Day 1 completed successfully.")
    print(f"Input: {source}")
    print(f"Rows processed: {len(engineered):,}")
    print(f"Engineered feature count: {results['summary']['engineered_feature_count']}")
    print(f"Features: {engineered_path}")
    print(f"Feature report: {report_path}")
    print(f"Profile summary: {summary_path}")


if __name__ == "__main__":
    main()
