import unittest
import pandas as pd

from scripts.week2_day1_feature_engineering import engineer_features


class TestFeatureEngineering(unittest.TestCase):
    def setUp(self):
        self.sample = pd.DataFrame({
            "step": [1, 2, 3],
            "type": ["PAYMENT", "TRANSFER", "CASH_OUT"],
            "amount": [100.0, 250.0, 500.0],
            "nameOrig": ["C1", "C2", "C3"],
            "oldbalanceOrg": [200.0, 300.0, 700.0],
            "newbalanceOrig": [100.0, 50.0, 200.0],
            "nameDest": ["M1", "C4", "C5"],
            "oldbalanceDest": [0.0, 10.0, 20.0],
            "newbalanceDest": [100.0, 260.0, 520.0],
            "isFraud": [0, 1, 1],
            "isFlaggedFraud": [0, 0, 0],
        })

    def test_expected_engineered_features_exist(self):
        features, result = engineer_features(self.sample)
        expected = {
            "amount_log1p", "hour_of_day", "day_index",
            "origin_balance_change", "origin_balance_error",
            "destination_balance_change", "destination_balance_error",
            "type_TRANSFER", "isFraud",
        }
        self.assertTrue(expected.issubset(set(features.columns)))
        self.assertEqual(result["summary"]["rows_after_duplicate_removal"], 3)

    def test_target_not_counted_as_model_feature(self):
        _, result = engineer_features(self.sample)
        self.assertNotIn("isFraud", result["feature_report"]["feature"].tolist())
        self.assertNotIn("isFlaggedFraud", result["feature_report"]["feature"].tolist())

    def test_duplicate_rows_removed(self):
        data = pd.concat([self.sample, self.sample.iloc[[0]]], ignore_index=True)
        features, result = engineer_features(data)
        self.assertEqual(len(features), 3)
        self.assertEqual(result["summary"]["duplicate_rows_removed"], 1)


if __name__ == "__main__":
    unittest.main()
