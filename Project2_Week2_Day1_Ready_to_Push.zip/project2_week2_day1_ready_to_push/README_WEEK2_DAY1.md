# Week 2 Day 1 — Ready-to-Push Package

This package adds PaySim transaction profiling and feature engineering to Project 2.

## Files
- `scripts/week2_day1_feature_engineering.py` — main implementation
- `tests/test_feature_engineering.py` — unit tests
- `docs/week2_day1_report.md` — work report and method notes

## Add to your existing repository
Extract/copy the `scripts/`, `tests/`, and `docs/` folders into the root of your Project 2 repository. If a folder already exists, merge the files; do not replace your existing folder contents.

Ensure the PaySim CSV is located under `data/paysim/`, or pass its path using `--input`.

## Run
```bash
pip install -r requirements.txt
python scripts/week2_day1_feature_engineering.py
python -m unittest discover -s tests -v
```

If your existing `requirements.txt` does not contain these libraries, add:
```text
pandas
numpy
```

## Git commands
```bash
git status
git checkout shubham
git add scripts/week2_day1_feature_engineering.py tests/test_feature_engineering.py docs/week2_day1_report.md
git commit -m "feat: add week 2 day 1 transaction feature engineering"
git push origin shubham
```

If your branch is already `shubham`, the checkout command is optional. Review `git status` before committing so you do not accidentally commit unrelated files.
